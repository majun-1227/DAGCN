import numpy as np

class kFoldGenerator():
    '''
    Data Generator x [(924,10,3000)...(766, 10, 3000)]y [(924,5)...(766,5)]
    '''
    k = -1      # the fold number
    x_list = [] # x list with length=k
    y_list = [] # x list with length=k

    # Initializate
    def __init__(self, x, y):
        if len(x) != len(y):
            assert False, 'Data generator: Length of x or y is not equal to k.'
        self.k = len(x)
        self.x_list = x
        
        self.y_list = y
        

    # Get i-th fold
    def getFold(self, i):
        isFirst = True
        print("*****我是self.k*****")
        print(self.k) # 10
        for p in range(self.k):
            #print("*****我是p*****")
            #print(p) # 0-9
            #print("*****我是i*****")
            #print(i) # 0-9
            if p != i:
                if isFirst:
                    train_data = self.x_list[p]
                    print("*****我是isFirst = Trued的train_data*****")
                    #print(train_data) 
                    print(train_data.shape) #(911,10,3000) 
                    train_targets = self.y_list[p]
                    print("*****我是isFirst = True的train_targets*****")
                    #print(train_targets)
                    print(train_targets.shape) # (911,5)
                    isFirst = False
                else:
                    train_data = np.concatenate((train_data, self.x_list[p]))
                    print("*****我是isFirst = False的train_data*****")
                    print(train_data.shape) #（911+794，10，3000）...(911+794+...+766,10,3000)
                    train_targets = np.concatenate((train_targets, self.y_list[p]))
                    print("*****我是isFirst = False的train_targets*****")
                    print(train_targets.shape)# (911+794，5)...(911+794+...+766,5)
            else:
                val_data = self.x_list[p]
                print("*****我是 p=i 的val_data*****")
                print(val_data.shape) #（924，10，3000）
                val_targets = self.y_list[p]
                print("*****我是 p=i 的val_targets*****")
                print(val_targets.shape) #（924，5）
        print("训练数据维度:", train_data.shape) # (16254, 10, 3000)
        print("训练标签维度:", train_targets.shape)# (16254, 5)
        print("验证数据维度:", val_data.shape) #  (924, 10, 3000)
        print("验证标签维度:", val_targets.shape)#  (924, 5)

        return train_data, train_targets, val_data, val_targets

    # Get all data x
    def getX(self):
        All_X = self.x_list[0]
        #print("*****我是All_X*****")
        #print(All_X)
        #print(All_X.shape) # (924,10,3000)
        for i in range(1, self.k):
            All_X = np.append(All_X, self.x_list[i], axis=0)
        return All_X # (8589,10,3000)

    # Get all label y (one-hot)
    def getY(self):
        All_Y = self.y_list[0][2:-2]
        for i in range(1, self.k):
            All_Y = np.append(All_Y, self.y_list[i][2:-2], axis=0)
        return All_Y

    # Get all label y (int)
    def getY_int(self):
        All_Y = self.getY()
        return np.argmax(All_Y, axis=1)
if __name__ == 'main':
    kFoldGenerator()

