import numpy as np
import tensorflow as tf
from keras import backend as K
from keras import layers
from keras import models
from keras.layers import Layer
from keras.layers.core import Dropout, Lambda
from tensorflow.python.framework import ops
from tensorflow.keras.layers import LayerNormalization
import copy
'''
Model code of MSTGCN.
--------
Model input:  (*, T, V, F)
    T: num_of_timesteps
    V: num_of_vertices
    F: num_of_features
Model output: (*, 5)
'''



################################################################################################
################################################################################################
# Some operations
def diff_loss(diff, S):
    '''
    compute the 1st loss of L_{graph_learning}
    '''
    if len(S.shape) == 4:
        # batch input
        return K.mean(K.sum(K.sum(diff**2, axis=3) * S, axis=(1, 2)))
    else:
        return K.sum(K.sum(diff**2, axis=2) * S)


def F_norm_loss(S, Falpha):
    '''
    compute the 2nd loss of L_{graph_learning}
    '''
    if len(S.shape) == 4:
        # batch input
        return Falpha * K.sum(K.mean(S**2, axis=0))
    else:
        return Falpha * K.sum(S**2)
    
def reshape_dot(x):
    #Input:  [x,TAtt]
    x, TAtt = x
    return tf.reshape(
        K.batch_dot(
            tf.reshape(tf.transpose(x, perm=[0, 2, 3, 1]),
                       (tf.shape(x)[0], -1, tf.shape(x)[1])), TAtt),
        [-1, x.shape[1], x.shape[2], x.shape[3]]
    )


def LayerNorm(x):
    # do the layer normalization
    relu_x = K.relu(x)
    ln = tf.contrib.layers.layer_norm(relu_x, begin_norm_axis=3)
    return ln

################################################################################################
################################################################################################
class Spatial_graph_conv(Layer):
    '''
    K-order chebyshev graph convolution after Graph Learn
    --------
    Input:  [x   (batch_size, num_of_timesteps, num_of_vertices, num_of_features),
             S   (batch_size, num_of_vertices, num_of_vertices)]
    Output: (batch_size, num_of_timesteps, num_of_vertices, num_of_filters)
    '''

    def __init__(self, num_of_filters, k, **kwargs):
        self.k = k
        self.num_of_filters = num_of_filters
        super(graph_conv, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)

        x_shape, S_shape = input_shape
        _, num_of_timesteps, num_of_vertices, num_of_features = x_shape
        self.Theta = self.add_weight(name='Theta',
                                     shape=(self.k, num_of_features, self.num_of_filters),
                                     initializer='uniform',
                                     trainable=True)



    def call(self, x):
        x, W = x
        _, num_of_timesteps, num_of_vertices, num_of_features = x.shape
     

        # 使用变量存储计算图中的张量值
        I = tf.ones(shape=(tf.shape(x)[0], num_of_vertices, num_of_vertices))

        #Graph Convolution

        D =tf.compat.v1.matrix_diag(K.sum(W, axis=1))
        L = D - W
        lambda_max = 2.0
        L_t = (2 * L) / lambda_max - [tf.eye(int(num_of_vertices))]
        cheb_polynomials = [tf.eye(int(num_of_vertices)), L_t]
        for i in range(2, self.k):
            cheb_polynomials.append(2 * L_t * cheb_polynomials[i - 1] - cheb_polynomials[i - 2])

        outputs = []
        for time_step in range(num_of_timesteps):
            # shape of x is (batch_size, V, F)
            graph_signal = x[:, time_step, :, :]
            # shape of x is (batch_size, V, F')
            print(tf.shape(x), num_of_vertices, self.num_of_filters)

            output = tf.zeros(shape=(tf.shape(x)[0], num_of_vertices, self.num_of_filters))

            for kk in range(self.k):
                # shape of T_k is (V, V)
                T_k = cheb_polynomials[kk]

                # shape of T_k_with_at is (batch_size, V, V)
                T_k = T_k * I

                # shape of theta_k is (F, num_of_filters)
                theta_k = self.Theta[kk]

                # shape is (batch_size, V, F)
                rhs = K.batch_dot(tf.transpose(T_k, perm=[0, 2, 1]), graph_signal)

                output = output + K.dot(rhs, theta_k)
            outputs.append(tf.expand_dims(output, 1))
        rs = K.relu(K.concatenate(outputs, axis=1))
        return rs

    def compute_output_shape(self, input_shape):
        assert isinstance(input_shape, list)
        # shape: (n, num_of_timesteps, num_of_vertices, num_of_filters)
        return (input_shape[0][0], input_shape[0][1], input_shape[0][2], self.num_of_filters)
        # return (input_shape[0][0], input_shape[0][1], input_shape[0][2], input_shape[0][2])

class temporal_graph_learning(Layer):
    '''
        Graph structure learning
        --------
        Input:  (batch_size, num_of_timesteps, num_of_vertices, num_of_features)
        Output: (batch_size, num_of_vertices, num_of_vertices)
    '''
    def __init__(self, **kwargs):
        self.S = tf.convert_to_tensor(0.0)
        super(temporal_graph_learning, self).__init__(**kwargs)

    def build(self, input_shape):

        _, num_of_timesteps, num_of_vertices, num_of_features = input_shape

        self.kernal = self.add_weight(name='kernel',
                                      shape=(num_of_features, num_of_vertices),
                                      initializer='uniform',
                                      trainable=True)

        self.add_loss(F_norm(self.S, 0.0005))
        super(temporal_graph_learning, self).build(input_shape)

    def call(self, x):
        S1 = K.dot(x,self.kernal)
        S = K.mean(S1,axis=1)
        self.S = S
        return  S

    def compute_output_shape(self, input_shape):
        # shape: (n, num_of_vertices, num_of_vertices)
        return (input_shape[0], input_shape[2], input_shape[2])
    def get_config(self):
        config = { 'S': self.S}
        base_config = super(temporal_graph_learning, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class Spatial_graph_learning(Layer):
    '''
    Graph structure learning (based on the middle time slice)
    --------
    Input:  (batch_size, num_of_timesteps, num_of_vertices, num_of_features)
    Output: (batch_size, num_of_vertices, num_of_vertices)
    '''

    def __init__(self, alpha, **kwargs):

        self.alpha = alpha
        self.S = tf.convert_to_tensor(0.0)
        self.diff = tf.convert_to_tensor([[[[0.0]]]])  # similar to placeholder
        super(functional_graph_learning, self).__init__(**kwargs)


    def build(self, input_shape):
        _, num_of_timesteps, num_of_vertices, num_of_features = input_shape

        self.a = self.add_weight(name='a',
                                 shape=(num_of_features, 1),
                                 initializer='uniform',
                                 trainable=True)
        self.add_loss(F_norm_loss(self.S, self.alpha))
        self.add_loss(diff_loss(self.diff, self.S))
        super(functional_graph_learning, self).build(input_shape)

    def call(self, x):
        _, T, V, F = x.shape
        N = tf.shape(x)[0]

        # shape: (N,V,F) use the current slice
        x = x[:, int(int(x.shape[1]) / 2), :, :]

        # shape: (N,V,V)
        diff = tf.transpose(tf.broadcast_to(x, [V, N, V, F]), perm=[2, 1, 0, 3]) - x

        # shape: (N,V,V)
        tmpS = K.exp(K.reshape(K.dot(tf.transpose(K.abs(diff), perm=[1, 0, 2, 3]), self.a), [N, V, V]))

        # shape: (N,V,V)
        S = tmpS / tf.transpose(tf.broadcast_to(K.sum(tmpS, axis=1), [V, N, V]), perm=[1, 2, 0])

        self.S = S
        self.diff = diff
        return S

    def compute_output_shape(self, input_shape):
        # shape: (n, num_of_vertices, num_of_vertices)
        return (input_shape[0], input_shape[2], input_shape[2])
    
class temporal_graph_conv(Layer):
    '''
    K-order chebyshev graph convolution after Graph Learn
    --------
    Input:  [x   (batch_size, num_of_timesteps, num_of_vertices, num_of_filters),
            S   (batch_size, num_of_vertices, num_of_vertices)]
    Output: (batch_size, num_of_timesteps, num_of_vertices, num_of_filters)
    '''

    def __init__(self, num_of_filters, k, **kwargs):
        self.k = k
        self.num_of_filters = num_of_filters
        super(graph_conv_with_jk, self).__init__(**kwargs)

    def build(self, input_shape):
        assert isinstance(input_shape, list)

        gcn_shape, S_shape = input_shape
        _, num_of_timesteps, num_of_vertices, num_of_filters = gcn_shape
        self.Theta = self.add_weight(name='Theta',
                                     shape=( self.k, self.num_of_filters ,self.num_of_filters),
                                     initializer='uniform',
                                     trainable=True)
        super(graph_conv_with_jk, self).build(input_shape)

    def call(self, x):

        gcn, W = x

        _, num_of_timesteps, num_of_vertices, num_of_filters = gcn.shape
        I = tf.ones(shape=(tf.shape(gcn)[0], num_of_vertices, num_of_vertices))

        outputs = []

        D = tf.linalg.diag(K.sum(W, axis=1))

        L = D - W
        lambda_max = 2.0
        L_t = (2 * L) / lambda_max - [tf.eye(int(num_of_vertices))]
        cheb_polynomials = [tf.eye(int(num_of_vertices)), L_t]
        for i in range(2, self.k):
            cheb_polynomials.append(2 * L_t * cheb_polynomials[i - 1] - cheb_polynomials[i - 2])

        for time_step in range(num_of_timesteps):
            # shape of x is (batch_size, V, F)
            graph_signal = gcn[:, time_step, :, :]
            # shape of x is (batch_size, V, F')

            output = tf.zeros(shape=(tf.shape(gcn)[0], num_of_vertices, self.num_of_filters))
            for kk in range(self.k):
                # shape of T_k is (V, V)
                T_k = cheb_polynomials[kk]

                # shape of T_k_with_at is (batch_size, V, V)
                T_k = T_k * I

                # shape of theta_k is (F, num_of_filters)
                theta_k = self.Theta[kk]

                # shape is (batch_size, V, F)
                rhs = K.batch_dot(tf.transpose(T_k, perm=[0, 2, 1]), graph_signal)

                output = output + K.dot(rhs, theta_k)
            outputs.append(tf.expand_dims(output, 1))
        gcn2 = K.relu(K.concatenate(outputs, axis=1))
        #jump knowledge
        jkgcn = gcn2  + K.sigmoid(gcn)
        return jkgcn
    def get_config(self):
        
        base_config = super(graph_conv_with_jk, self).get_config()
        return base_config   
################################################################################################
################################################################################################
# DAGCN Block

def DAGCN_Block(x, k, num_of_chev_filters, num_of_time_filters, time_conv_strides,
                 cheb_polynomials, time_conv_kernel, GLalpha, i=0):
    '''
    packaged Spatial-temporal convolution Block
    -------
    x: input data;
    k: k-order cheb GCN
    i: block number
    '''
  
    x= STSelfAttention(dim=40,s_attn_size=3,t_attn_size=3)(x)
   
   #Spatial graph learning
    S = Spatial_graph_learning(alpha=GLalpha)(x)
    S = layers.Dropout(0.3)(S)
    print(S.shape)

    # first graph convolution layer with function based adaptive graph
    Sgcn = Spatial_graph_conv(num_of_filters=num_of_chev_filters, k=k)([x, S])
                             

    # temporal graph learning
    T = temporal_graph_learning()(x)
    T = layers.Dropout(0.5)(T)
    
    #  graph convolution with temporal information based adaptive graph
    Dagcn = temporal_graph_conv(num_of_filters=num_of_chev_filters, k=k)([Sgcn, T])
    

    block_out = layers.Dropout(0.5)(Dagcn)

    # temporal convolution
    time_conv_output = layers.Conv2D(
        filters=num_of_time_filters,
        kernel_size=(time_conv_kernel, 1),
        padding='same',
        strides=(time_conv_strides, 1)
    )(block_out)
                             
    return time_conv_output
################################################################################################
################################################################################################
# MSTGCN

def build_DAGCN(k, num_of_chev_filters, num_of_time_filters, time_conv_strides, cheb_polynomials,
                 time_conv_kernel, sample_shape, num_block, dense_size, opt, GLalpha,
                 regularizer, dropout,num_classes=5, ):

    # Input:  (*, num_of_timesteps, num_of_vertices, num_of_features)
    data_layer = layers.Input(shape=sample_shape, name='Input-Data')

    block_out = DAGCN_Block(data_layer, k, num_of_chev_filters, num_of_time_filters,
                                              time_conv_strides, cheb_polynomials, time_conv_kernel, GLalpha)

    block_out = layers.Flatten()(block_out)

    for size in dense_size:
        block_out = layers.Dense(size,activation='relu',kernel_regularizer=regularizer)(block_out)

    # dropout
    if dropout != 0:
        block_out = layers.Dropout(dropout)(block_out)

    softmax = layers.Dense(5, activation='softmax')(block_out)

    model = models.Model(inputs=data_layer, outputs=softmax)

    model.compile(
        optimizer=opt,
        loss='categorical_crossentropy',
        metrics=['acc'],
    )
    
    return model

