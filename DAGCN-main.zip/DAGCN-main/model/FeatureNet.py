import tensorflow as tf
import keras
from keras.models import Model
from keras.layers import Input, Conv1D, Dense, Dropout, MaxPool1D, Activation
from keras.layers import Flatten, Reshape, TimeDistributed, BatchNormalization

from tensorflow.keras.layers import Conv1D, Dense, Dropout, Flatten, MaxPooling1D, Activation,\
BatchNormalization, Add, Reshape, TimeDistributed, Input, GlobalAveragePooling1D
from tensorflow.keras.models import Model
from tensorflow.keras.regularizers import l2
'''
A Feature Extractor Network
'''
def CNN(inputs, fs=32, kernel_size=25, pool_size=16, weight=0.001):
    x = Conv1D(fs, kernel_size,1, padding='same', kernel_regularizer=l2(weight))(inputs)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling1D(pool_size, 2, padding='same')(x)
    return x

def ResNet(inputs, fs=32, ks_1=25, ps_1=16, ks_2=25, ps_2=16, weight=0.001):
    x = CNN(inputs, fs, ks_1, ps_1,weight)
    x = CNN(x, fs, ks_2, ps_2,weight)
    shortcut_x = Conv1D(fs,1,2,padding='same')(inputs)
    shortcut_x = Conv1D(fs,1,2,padding='same')(shortcut_x)
    return Add()([x, shortcut_x])
def build_FeatureNet(opt, channels=10, time_second=30, freq=100):
    activation = tf.nn.relu
    padding = 'same'

    ######### Input ########
    input_signal = Input(shape=(time_second * freq, 1), name='input_signal')
    x1 = ResNet(input_signal, 16)
    x1 = Dropout(0.2)(x1)
    x1 = ResNet(x1, 32)
    x1 = Dropout(0.2)(x1)
    x2 = ResNet(input_signal, 64)
    x2= Dropout(0.2)(x2)
    
    x2 = ResNet(x2, 128)
    x2 = Dropout(0.2)(x2)

    x = keras.layers.concatenate([x1, x2])

    outputs = GlobalAveragePooling1D()(x)

    fea_part = Model(inputs=input_signal, outputs=outputs)
    fea_part.summary()

    ##################################################

    input = Input(shape=(channels, time_second * freq), name='input_signal')
    reshape = Reshape((channels, time_second * freq, 1))  # Flatten
    input_re = reshape(input)
    fea_all = TimeDistributed(fea_part)(input_re)

    merged = Flatten()(fea_all)
    merged = Dropout(0.5)(merged)
    merged = Dense(64)(merged)
    merged = Dense(5)(merged)

    fea_softmax = Activation(activation='softmax')(merged)
    
    

    # FeatureNet with softmax
    fea_model = Model(input, fea_softmax)
    fea_model.compile(optimizer=opt,
                      loss='categorical_crossentropy',
                      metrics=['acc'])

    # FeatureNet without softmax
    pre_model = Model(input, fea_all)
    pre_model.compile(optimizer=opt,
                      loss='categorical_crossentropy',
                      metrics=['acc'])

    return fea_model, pre_model
